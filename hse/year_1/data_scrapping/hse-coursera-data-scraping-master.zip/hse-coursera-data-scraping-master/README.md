# hse-coursera-data-scraping
Resources for "Data Scraping" course. 
